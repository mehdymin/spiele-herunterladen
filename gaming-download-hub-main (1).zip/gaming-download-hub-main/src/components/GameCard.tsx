import { useState } from "react";
import { Download, Star } from "lucide-react";

interface GameCardProps {
  title: string;
  description: string;
  image: string;
  rating: number;
  downloads: string;
  downloadLink: string;
}

const GameCard = ({
  title,
  description,
  image,
  rating,
  downloads,
  downloadLink,
}: GameCardProps) => {
  const [imageLoaded, setImageLoaded] = useState(false);

  return (
    <div className="relative group">
      <div className="relative overflow-hidden rounded-lg transition-all duration-300 transform hover:scale-[1.02]">
        <div className="absolute inset-0 bg-black/20 backdrop-blur-[2px] group-hover:backdrop-blur-[4px] transition-all duration-300" />
        
        <div className="relative aspect-[16/9]">
          <img
            src={image}
            alt={title}
            className={`w-full h-full object-cover transition-opacity duration-700 ${
              imageLoaded ? "opacity-100" : "opacity-0"
            }`}
            onLoad={() => setImageLoaded(true)}
          />
          <div className={`absolute inset-0 bg-gray-200 animate-pulse ${
            imageLoaded ? "hidden" : "block"
          }`} />
        </div>

        <div className="absolute bottom-0 left-0 right-0 p-6 text-white">
          <div className="flex items-center gap-2 mb-2">
            <span className="px-3 py-1 rounded-full bg-accent/90 text-xs font-medium">
              {downloads} Downloads
            </span>
            <div className="flex items-center gap-1">
              <Star className="w-4 h-4 fill-yellow-400 stroke-yellow-400" />
              <span className="text-sm font-medium">{rating.toFixed(1)}</span>
            </div>
          </div>
          
          <h3 className="text-2xl font-bold mb-2">{title}</h3>
          <p className="text-sm text-white/90 mb-4 line-clamp-2">{description}</p>
          
          <a
            href={downloadLink}
            className="inline-flex items-center gap-2 px-6 py-3 rounded-lg bg-white/10 hover:bg-white/20 backdrop-blur-sm transition-all duration-300 text-white font-medium"
          >
            <Download className="w-5 h-5" />
            Download Now
          </a>
        </div>
      </div>
    </div>
  );
};

export default GameCard;