import { useEffect, useState } from "react";

interface StatsCounterProps {
  end: number;
  duration?: number;
  suffix?: string;
}

const StatsCounter = ({ end, duration = 2000, suffix = "" }: StatsCounterProps) => {
  const [count, setCount] = useState(0);

  useEffect(() => {
    const steps = 60;
    const increment = end / steps;
    const stepDuration = duration / steps;
    let current = 0;
    let timer: NodeJS.Timeout;

    const updateCount = () => {
      current += increment;
      if (current > end) {
        current = end;
        setCount(end);
        clearInterval(timer);
      } else {
        setCount(Math.floor(current));
      }
    };

    timer = setInterval(updateCount, stepDuration);
    return () => clearInterval(timer);
  }, [end, duration]);

  return (
    <span className="font-bold text-4xl">
      {count.toLocaleString()}
      {suffix}
    </span>
  );
};

export default StatsCounter;