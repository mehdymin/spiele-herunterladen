import { useEffect, useState } from "react";
import GameCard from "@/components/GameCard";
import StatsCounter from "@/components/StatsCounter";
import Newsletter from "@/components/Newsletter";
import { Monitor, Cpu, HardDrive } from "lucide-react";

const Index = () => {
  const [scrollY, setScrollY] = useState(0);

  useEffect(() => {
    const handleScroll = () => setScrollY(window.scrollY);
    window.addEventListener("scroll", handleScroll);
    return () => window.removeEventListener("scroll", handleScroll);
  }, []);

  return (
    <div className="min-h-screen bg-primary text-white">
      {/* Hero Section */}
      <section className="relative h-screen flex items-center justify-center overflow-hidden">
        <div
          className="absolute inset-0 z-0"
          style={{
            transform: `translateY(${scrollY * 0.5}px)`,
            backgroundImage: "url('https://images.unsplash.com/photo-1485827404703-89b55fcc595e')",
            backgroundSize: "cover",
            backgroundPosition: "center",
            filter: "brightness(0.4)",
          }}
        />
        <div className="container relative z-10 text-center">
          <h1 className="text-6xl font-bold mb-6 animate-float">
            Download Your Favorite Games
          </h1>
          <p className="text-xl text-white/80 max-w-2xl mx-auto mb-8">
            Get instant access to Minecraft and FIFA. Join millions of players worldwide.
          </p>
        </div>
      </section>

      {/* Games Section */}
      <section className="py-20 bg-gradient-to-b from-primary to-primary/95">
        <div className="container">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            <GameCard
              title="Minecraft"
              description="Build, explore, and survive in a blocky, procedurally-generated 3D world."
              image="https://images.unsplash.com/photo-1485827404703-89b55fcc595e"
              rating={4.8}
              downloads="1M+"
              downloadLink="#"
            />
            <GameCard
              title="FIFA 24"
              description="Experience the beautiful game with stunning graphics and realistic gameplay."
              image="https://images.unsplash.com/photo-1486312338219-ce68d2c6f44d"
              rating={4.6}
              downloads="500K+"
              downloadLink="#"
            />
          </div>
        </div>
      </section>

      {/* Stats Section */}
      <section className="py-20 bg-accent">
        <div className="container">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8 text-center">
            <div className="space-y-2">
              <StatsCounter end={2000000} suffix="+" />
              <p className="text-white/80">Downloads</p>
            </div>
            <div className="space-y-2">
              <StatsCounter end={500000} suffix="+" />
              <p className="text-white/80">Active Players</p>
            </div>
            <div className="space-y-2">
              <StatsCounter end={98} suffix="%" />
              <p className="text-white/80">Satisfaction Rate</p>
            </div>
          </div>
        </div>
      </section>

      {/* System Requirements */}
      <section className="py-20 bg-primary">
        <div className="container">
          <h2 className="text-4xl font-bold text-center mb-12">System Requirements</h2>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {[
              {
                icon: Monitor,
                title: "Graphics",
                specs: "NVIDIA GeForce GTX 660 or AMD Radeon HD 7870",
              },
              {
                icon: Cpu,
                title: "Processor",
                specs: "Intel Core i5-4690 or AMD A10-7800",
              },
              {
                icon: HardDrive,
                title: "Storage",
                specs: "4 GB available space",
              },
            ].map((req, index) => (
              <div
                key={index}
                className="p-6 rounded-lg bg-white/5 backdrop-blur-sm hover:bg-white/10 transition-colors duration-300"
              >
                <req.icon className="w-8 h-8 mb-4 text-accent" />
                <h3 className="text-xl font-semibold mb-2">{req.title}</h3>
                <p className="text-white/80">{req.specs}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Newsletter Section */}
      <section className="py-20 bg-gradient-to-t from-primary to-primary/95">
        <div className="container text-center">
          <h2 className="text-4xl font-bold mb-4">Stay Updated</h2>
          <p className="text-white/80 mb-8 max-w-md mx-auto">
            Subscribe to our newsletter for the latest game updates and exclusive offers.
          </p>
          <Newsletter />
        </div>
      </section>
    </div>
  );
};

export default Index;